CarrierWave.configure do |config|
  config.fog_provider = 'fog/aws'                        # required
  config.fog_credentials = {
    provider:              'AWS',                        # required
    aws_access_key_id:     'AKIAIXYO6CBMPWVRPZDA',                        # required unless using use_iam_profile
    aws_secret_access_key: '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',                        # required unless using use_iam_profile
  }
  config.fog_directory  = 'offcampustigers'                                      # required

end