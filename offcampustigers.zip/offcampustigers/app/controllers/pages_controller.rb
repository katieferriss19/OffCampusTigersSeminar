class PagesController < ApplicationController
  def about
  end

  def contact
  end
end
