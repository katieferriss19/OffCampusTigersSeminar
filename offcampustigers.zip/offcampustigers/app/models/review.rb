#Link users to reviews and ensure that reviews will be destroyed when their author is deleted
class Review < ActiveRecord::Base
  belongs_to :user
  belongs_to :restaurant

  #adding more validations to reviews
  validates :rating, :comment, presence: true
  #make sure the rating is numnerical
  validates :rating, numericality: {
    only_integer: true,
    greater_than_or_equal_to: 1,
    less_than_or_equal_to: 5,
    message: "Can only be a whole number between 1 and 5."
  }
end