#Link users to reviews and ensure that reviews will be destroyed when their author is deleted
class User < ActiveRecord::Base
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable and :omniauthable
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :trackable, :validatable
  has_many :reviews, dependent: :destroy  

  #new error messages when signing up, must have a first and last name
  validates :first_name, :last_name, presence: true
end